<?php namespace App\Models\General\Traits\Relationship;

trait Relationship
{
}