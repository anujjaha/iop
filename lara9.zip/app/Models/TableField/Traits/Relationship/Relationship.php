<?php namespace App\Models\TableField\Traits\Relationship;

trait Relationship
{
}