<?php

namespace App\Models\User\Traits\Relationship;

/**
 * Class UserRelationship.
 */
trait UserRelationship
{
}