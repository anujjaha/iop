<?php namespace App\Models\Visit\Traits\Relationship;

trait Relationship
{
}